# IPL_prediction-
Prediction of 2019 ipl matches using data from (2008-2018)
